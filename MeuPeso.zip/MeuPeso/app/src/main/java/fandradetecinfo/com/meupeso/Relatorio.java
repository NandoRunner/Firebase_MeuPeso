package fandradetecinfo.com.meupeso;

/**
 * Created by Fernando on 08/03/2017.
 */


public enum Relatorio {
    Registros,
    Medias,
    Totais
}
