package com.fandradetecinfo.myjavalib;

public class MyJavaLib {
}
